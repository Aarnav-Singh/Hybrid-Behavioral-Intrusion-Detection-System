"""
evaluate.py
===========
Evaluation harness for the Hybrid Behavioral IDS.

Runs three detector configurations independently and compares them:
  1. rule_only    — deterministic rule engine
  2. ml_only      — Isolation Forest anomaly detection
  3. behavioral   — behavioral baseliner only
  4. hybrid       — full fusion of all three (default)

Generates:
  - Precision, Recall, F1, ROC-AUC per mode
  - Comparison table (proves hybrid outperforms any single detector)
  - Per-attack-type breakdown
  - Drift performance comparison across stream phases

Usage:
    python evaluate.py --mode hybrid
    python evaluate.py --mode all              # run all modes and compare
    python evaluate.py --mode all --drift gradual
    python evaluate.py --mode hybrid --n-events 5000
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
from sklearn.metrics import (
    classification_report,
    precision_recall_fscore_support,
    roc_auc_score,
    confusion_matrix,
)

# Local imports
sys.path.insert(0, str(Path(__file__).parent))

from baseliner.behavioral_baseliner import BehavioralBaseliner, EntityEvent
from detectors.ml_detector import MLAnomalyDetector
from detectors.rule_engine import RuleEngine
from drift.drift_simulator import DriftSimulator, SimulatedEvent
from fusion.hybrid_scorer import DetectorSignals, HybridFusionEngine

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("evaluate")


# ---------------------------------------------------------------------------
# Evaluation Pipeline
# ---------------------------------------------------------------------------

class EvaluationPipeline:
    """
    Orchestrates the full evaluation across multiple detector modes.

    Each mode uses the same event stream and ground truth labels,
    ensuring a fair comparison.
    """

    def __init__(
        self,
        n_events: int = 2000,
        drift_type: str = "none",
        attack_ratio: float = 0.08,
        alert_threshold: float = 0.50,
        seed: int = 42,
    ):
        self.n_events = n_events
        self.drift_type = drift_type
        self.attack_ratio = attack_ratio
        self.alert_threshold = alert_threshold
        self.seed = seed

        logger.info(
            f"EvaluationPipeline | n_events={n_events} | "
            f"drift={drift_type} | attack_ratio={attack_ratio}"
        )

    def _build_stream(self) -> List[SimulatedEvent]:
        sim = DriftSimulator(seed=self.seed, attack_ratio=self.attack_ratio)
        return sim.generate_stream(self.n_events, drift_type=self.drift_type)

    def _train_detectors(
        self, stream: List[SimulatedEvent]
    ) -> Tuple[RuleEngine, MLAnomalyDetector, BehavioralBaseliner]:
        """
        Use the first 30% of normal events to train/warm up detectors.
        Attackers do not contribute to training data.
        """
        train_cutoff = int(len(stream) * 0.30)
        train_events = [e for e in stream[:train_cutoff] if not e.is_attack]

        logger.info(f"Training on {len(train_events)} normal events from first 30% of stream")

        # Rule engine (no training needed)
        rule_engine = RuleEngine().load_default_rules()

        # ML detector
        ml_detector = MLAnomalyDetector(contamination=self.attack_ratio)
        ml_features = [e.features for e in train_events]
        ml_detector.fit(ml_features)

        # Behavioral baseliner
        baseliner = BehavioralBaseliner()
        for e in train_events:
            entity_event = EntityEvent(
                entity_id=e.entity_id,
                timestamp=e.timestamp,
                features=e.features,
            )
            baseliner.ingest(entity_event)

        return rule_engine, ml_detector, baseliner

    # ------------------------------------------------------------------
    # Single-mode scoring
    # ------------------------------------------------------------------

    def _score_stream(
        self,
        stream: List[SimulatedEvent],
        mode: str,
        rule_engine: RuleEngine,
        ml_detector: MLAnomalyDetector,
        baseliner: BehavioralBaseliner,
        fusion_engine: HybridFusionEngine,
    ) -> List[Tuple[float, bool]]:
        """
        Score every event in the stream under the given mode.
        Returns list of (score, ground_truth_is_attack).
        """
        results = []
        train_cutoff_idx = int(len(stream) * 0.30)

        for i, event in enumerate(stream):
            entity_event = EntityEvent(
                entity_id=event.entity_id,
                timestamp=event.timestamp,
                features=event.features,
            )

            # Score using each detector
            rule_score, _ = rule_engine.evaluate(event.features)
            ml_score, _ = ml_detector.score_event(event.features)
            behavioral_score, _ = baseliner.score(entity_event)

            if mode == "rule_only":
                final_score = rule_score

            elif mode == "ml_only":
                final_score = ml_score

            elif mode == "behavioral_only":
                final_score = behavioral_score

            elif mode == "hybrid":
                signals = DetectorSignals(
                    ml_score=ml_score,
                    rule_score=rule_score,
                    behavioral_score=behavioral_score,
                    entity_id=event.entity_id,
                    timestamp=event.timestamp,
                )
                result = fusion_engine.evaluate(signals)
                final_score = result.hybrid_score

            else:
                raise ValueError(f"Unknown mode: {mode}")

            results.append((final_score, event.is_attack))

        return results

    # ------------------------------------------------------------------
    # Metrics Computation
    # ------------------------------------------------------------------

    def _compute_metrics(
        self,
        results: List[Tuple[float, bool]],
        threshold: float,
    ) -> dict:
        scores = np.array([r[0] for r in results])
        labels = np.array([int(r[1]) for r in results])
        predictions = (scores >= threshold).astype(int)

        prec, rec, f1, _ = precision_recall_fscore_support(
            labels, predictions, average="binary", zero_division=0
        )

        try:
            auc = roc_auc_score(labels, scores)
        except ValueError:
            auc = float("nan")

        tn, fp, fn, tp = confusion_matrix(labels, predictions, labels=[0, 1]).ravel()

        return {
            "precision": round(float(prec), 4),
            "recall":    round(float(rec), 4),
            "f1_score":  round(float(f1), 4),
            "roc_auc":   round(float(auc), 4),
            "tp": int(tp), "fp": int(fp),
            "tn": int(tn), "fn": int(fn),
            "false_positive_rate": round(fp / max(fp + tn, 1), 4),
            "false_negative_rate": round(fn / max(fn + tp, 1), 4),
            "total_events": len(results),
            "total_alerts": int(predictions.sum()),
        }

    def _compute_drift_breakdown(
        self,
        stream: List[SimulatedEvent],
        results: List[Tuple[float, bool]],
        threshold: float,
    ) -> dict:
        """Compute metrics per drift phase."""
        phases = {}
        for phase in ("pre_drift", "during_drift", "post_drift"):
            phase_results = [
                results[i] for i, e in enumerate(stream)
                if e.drift_phase == phase
            ]
            if len(phase_results) < 10:
                continue
            phases[phase] = self._compute_metrics(phase_results, threshold)
        return phases

    def _compute_attack_type_breakdown(
        self,
        stream: List[SimulatedEvent],
        results: List[Tuple[float, bool]],
        threshold: float,
    ) -> dict:
        """Compute detection rate per attack type."""
        attack_types = {}
        for i, event in enumerate(stream):
            if not event.is_attack:
                continue
            atype = event.attack_type
            score, label = results[i]
            detected = score >= threshold
            if atype not in attack_types:
                attack_types[atype] = {"detected": 0, "total": 0}
            attack_types[atype]["total"] += 1
            if detected:
                attack_types[atype]["detected"] += 1

        return {
            atype: {
                "detection_rate": round(v["detected"] / max(v["total"], 1), 4),
                "detected": v["detected"],
                "total": v["total"],
            }
            for atype, v in attack_types.items()
        }

    # ------------------------------------------------------------------
    # Main Evaluation Entry
    # ------------------------------------------------------------------

    def run(self, modes: List[str]) -> dict:
        """
        Run evaluation for the given modes.
        Returns a dict of mode → metrics.
        """
        stream = self._build_stream()
        rule_engine, ml_detector, baseliner = self._train_detectors(stream)

        fusion_engine = HybridFusionEngine(
            alert_threshold=self.alert_threshold,
            strategy="weighted",
        )

        all_results = {}

        for mode in modes:
            logger.info(f"Evaluating mode: {mode}")
            t0 = time.perf_counter()

            results = self._score_stream(
                stream, mode, rule_engine, ml_detector, baseliner, fusion_engine
            )

            elapsed = time.perf_counter() - t0
            metrics = self._compute_metrics(results, self.alert_threshold)
            metrics["eval_time_sec"] = round(elapsed, 3)
            metrics["throughput_eps"] = round(len(stream) / elapsed, 1)

            if self.drift_type != "none":
                metrics["drift_phase_breakdown"] = self._compute_drift_breakdown(
                    stream, results, self.alert_threshold
                )

            metrics["attack_type_breakdown"] = self._compute_attack_type_breakdown(
                stream, results, self.alert_threshold
            )

            all_results[mode] = metrics
            logger.info(f"Mode {mode}: F1={metrics['f1_score']} | AUC={metrics['roc_auc']} | FPR={metrics['false_positive_rate']}")

        return all_results


# ---------------------------------------------------------------------------
# Output Formatting
# ---------------------------------------------------------------------------

def print_comparison_table(results: dict):
    """Print a clean comparison table to stdout."""

    MODES = ["rule_only", "ml_only", "behavioral_only", "hybrid"]
    present = [m for m in MODES if m in results]

    header = f"\n{'='*70}"
    print(header)
    print(f"  HYBRID BEHAVIORAL IDS — DETECTOR COMPARISON")
    print(f"{'='*70}")
    print(f"  {'Mode':<22} {'Precision':>10} {'Recall':>10} {'F1':>10} {'AUC':>10} {'FPR':>10}")
    print(f"  {'-'*22} {'-'*10} {'-'*10} {'-'*10} {'-'*10} {'-'*10}")

    for mode in present:
        m = results[mode]
        marker = " ◄" if mode == "hybrid" else ""
        print(
            f"  {mode:<22} {m['precision']:>10.4f} {m['recall']:>10.4f} "
            f"{m['f1_score']:>10.4f} {m['roc_auc']:>10.4f} {m['false_positive_rate']:>10.4f}"
            f"{marker}"
        )

    print(f"{'='*70}\n")

    # Attack type breakdown for hybrid
    if "hybrid" in results and "attack_type_breakdown" in results["hybrid"]:
        print(f"  HYBRID — Per-Attack-Type Detection Rate")
        print(f"  {'-'*45}")
        for atype, stats in results["hybrid"]["attack_type_breakdown"].items():
            bar_len = int(stats["detection_rate"] * 20)
            bar = "█" * bar_len + "░" * (20 - bar_len)
            print(
                f"  {atype:<22} {bar} {stats['detection_rate']*100:>5.1f}%  "
                f"({stats['detected']}/{stats['total']})"
            )
        print()

    # Drift breakdown
    if "hybrid" in results and "drift_phase_breakdown" in results["hybrid"]:
        print(f"  HYBRID — Performance Across Drift Phases")
        print(f"  {'-'*55}")
        for phase, m in results["hybrid"]["drift_phase_breakdown"].items():
            print(
                f"  {phase:<20} F1={m['f1_score']:.4f} | "
                f"Recall={m['recall']:.4f} | FPR={m['false_positive_rate']:.4f}"
            )
        print()


# ---------------------------------------------------------------------------
# CLI Entry Point
# ---------------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser(
        description="HBIDS Evaluation Harness",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--mode",
        choices=["rule_only", "ml_only", "behavioral_only", "hybrid", "all"],
        default="all",
        help="Which detector configuration to evaluate",
    )
    parser.add_argument(
        "--drift",
        choices=["none", "sudden", "gradual", "recurring"],
        default="none",
        help="Type of concept drift to simulate",
    )
    parser.add_argument(
        "--n-events",
        type=int,
        default=2000,
        help="Number of events in the test stream",
    )
    parser.add_argument(
        "--attack-ratio",
        type=float,
        default=0.08,
        help="Fraction of events that are attacks",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.50,
        help="Alert threshold for binary classification",
    )
    parser.add_argument(
        "--output-json",
        type=str,
        default=None,
        help="If set, save full results to this JSON file",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
    )
    return parser.parse_args()


def main():
    args = parse_args()

    modes_to_run = (
        ["rule_only", "ml_only", "behavioral_only", "hybrid"]
        if args.mode == "all"
        else [args.mode]
    )

    pipeline = EvaluationPipeline(
        n_events=args.n_events,
        drift_type=args.drift,
        attack_ratio=args.attack_ratio,
        alert_threshold=args.threshold,
        seed=args.seed,
    )

    results = pipeline.run(modes_to_run)
    print_comparison_table(results)

    if args.output_json:
        with open(args.output_json, "w") as f:
            json.dump(results, f, indent=2)
        print(f"Full results saved to {args.output_json}")


if __name__ == "__main__":
    main()
